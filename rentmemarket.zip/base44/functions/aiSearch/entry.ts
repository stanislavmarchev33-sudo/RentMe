import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  const base44 = createClientFromRequest(req);

  const { query, listings } = await req.json();

  if (!query || !listings || listings.length === 0) {
    return Response.json({ ids: [], suggestion: null });
  }

  // Build a compact catalog for the AI
  const catalog = listings.map(l => ({
    id: l.id,
    title: l.title,
    description: (l.description || '').slice(0, 200),
    category: l.category_id || '',
    brand: l.brand || '',
    is_promoted: !!l.is_promoted,
  }));

  const result = await base44.asServiceRole.integrations.Core.InvokeLLM({
    prompt: `You are a smart search engine for a Bulgarian rental marketplace called RentMe.

User query: "${query}"

Below is the catalog of available listings in JSON format:
${JSON.stringify(catalog, null, 2)}

Your task:
1. Find all listings that are relevant to the user's query. Use semantic understanding — match by intent, not just keywords. Consider synonyms, related concepts, and context.
2. Promoted listings (is_promoted: true) should appear FIRST among results if they are relevant.
3. Return the IDs of relevant listings ordered by relevance (best match first, promoted ones elevated).
4. If NO listings match at all, return an empty ids array and a short suggestion in Bulgarian (e.g. what category they might look in).

Return ONLY valid JSON matching this schema.`,
    response_json_schema: {
      type: 'object',
      properties: {
        ids: {
          type: 'array',
          items: { type: 'string' },
          description: 'Ordered list of listing IDs, most relevant first. Promoted relevant listings come first.',
        },
        suggestion: {
          type: 'string',
          description: 'If no results found, a short Bulgarian suggestion for the user. Otherwise null.',
        },
      },
      required: ['ids'],
    },
  });

  return Response.json({
    ids: result.ids || [],
    suggestion: result.suggestion || null,
  });
});