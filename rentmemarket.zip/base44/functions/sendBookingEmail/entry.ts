import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

const APP_URL = 'https://rentmemarket.com';

const TEMPLATES = {
  booking_request: ({ renterName, listingTitle, startDate, endDate, bookingId }) => ({
    subject: `Нова заявка за наем — ${listingTitle}`,
    body: `Здравейте,\n\n${renterName} иска да наеме "${listingTitle}" от ${startDate} до ${endDate}.\n\nВлезте в RentMe за да одобрите или откажете заявката:\n${APP_URL}/booking/${bookingId}\n\nЕкипът на RentMe`,
  }),
  booking_approved: ({ ownerName, listingTitle, bookingId }) => ({
    subject: `Заявката ти е одобрена — ${listingTitle}`,
    body: `Здравейте,\n\n${ownerName} одобри заявката ти за "${listingTitle}".\n\nИмаш 30 минути да завършиш плащането. Влез в RentMe сега:\n${APP_URL}/booking/${bookingId}\n\nЕкипът на RentMe`,
  }),
  booking_rejected: ({ ownerName, listingTitle, bookingId }) => ({
    subject: `Заявката ти е отказана — ${listingTitle}`,
    body: `Здравейте,\n\n${ownerName} отказа заявката ти за "${listingTitle}".\n\nМожеш да разгледаш други обяви на:\n${APP_URL}/browse\n\nЕкипът на RentMe`,
  }),
  payment_received: ({ renterName, listingTitle, bookingId }) => ({
    subject: `Плащането е получено — ${listingTitle}`,
    body: `Здравейте,\n\n${renterName} плати за наема на "${listingTitle}".\n\nПодгответе артикула за предаване и маркирайте като изпратен:\n${APP_URL}/booking/${bookingId}\n\nЕкипът на RentMe`,
  }),
  item_sent: ({ ownerName, listingTitle, bookingId }) => ({
    subject: `Артикулът е изпратен — ${listingTitle}`,
    body: `Здравейте,\n\n${ownerName} изпрати "${listingTitle}".\n\nПотвърдете получаването в рамките на 48 часа:\n${APP_URL}/booking/${bookingId}\n\nЕкипът на RentMe`,
  }),
  booking_completed_renter: ({ listingTitle, bookingId }) => ({
    subject: `Наемът е завършен — ${listingTitle}`,
    body: `Здравейте,\n\nНаемът на "${listingTitle}" е завършен успешно!\n\nОставете рецензия и разгледайте нови обяви:\n${APP_URL}/booking/${bookingId}\n\nЕкипът на RentMe`,
  }),
  booking_completed_owner: ({ listingTitle, bookingId }) => ({
    subject: `Наемът е завършен — ${listingTitle}`,
    body: `Здравейте,\n\nНаемът на "${listingTitle}" е завършен успешно! Депозитът ще бъде освободен.\n\nОставете рецензия:\n${APP_URL}/booking/${bookingId}\n\nЕкипът на RentMe`,
  }),
};

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    const { templateKey, to, params } = await req.json();

    if (!templateKey || !to || !params) {
      return Response.json({ error: 'Missing templateKey, to, or params' }, { status: 400 });
    }

    const template = TEMPLATES[templateKey];
    if (!template) {
      return Response.json({ error: `Unknown template: ${templateKey}` }, { status: 400 });
    }

    const { subject, body } = template(params);

    await base44.asServiceRole.integrations.Core.SendEmail({
      to,
      subject,
      body,
      from_name: 'RentMe',
    });

    return Response.json({ ok: true });
  } catch (error) {
    console.error('sendBookingEmail error:', error.message, error.stack);
    return Response.json({ error: error.message }, { status: 500 });
  }
});