import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronLeft, ShieldCheck, AlertTriangle, FileText, Info } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

export default function InsuranceInfoPage() {
  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-10">
      <Link to="/" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-6">
        <ChevronLeft className="w-4 h-4" /> Начало
      </Link>

      <div className="flex items-center gap-3 mb-2">
        <div className="w-12 h-12 gradient-brand rounded-2xl flex items-center justify-center">
          <ShieldCheck className="w-6 h-6 text-white" />
        </div>
        <h1 className="font-heading text-3xl font-bold text-[#1e2a6e]">Депозит и застраховка</h1>
      </div>
      <p className="text-sm text-muted-foreground mb-10">Как работи защитата на RentMe за собственици и наематели</p>

      {/* Deposit */}
      <section className="mb-10">
        <h2 className="font-heading font-bold text-xl text-[#1e2a6e] mb-4">💰 Как работи депозитът?</h2>
        <div className="space-y-3">
          <Card>
            <CardContent className="p-5 text-sm text-gray-600 leading-relaxed space-y-2">
              <p>• Депозитът е <strong>20% от оценената стойност</strong> на вещта, изчислена автоматично от AI.</p>
              <p>• При плащане сумата се <strong>блокира</strong> от картата на Наемателя, но не се прехвърля.</p>
              <p>• Депозитът се <strong>отключва автоматично 48 часа</strong> след потвърдено връщане от Собственика.</p>
              <p>• Ако Собственикът не отговори в 48 часа — депозитът се освобождава автоматично.</p>
              <p>• При установена повреда, кражба или загуба — депозитът (или част от него) може да се задържи.</p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* What is covered */}
      <section className="mb-10">
        <h2 className="font-heading font-bold text-xl text-[#1e2a6e] mb-4">✅ Какво покрива защитата?</h2>
        <div className="grid sm:grid-cols-3 gap-3">
          {[
            { icon: '🔨', title: 'Случайна повреда', desc: 'Увреждане на вещта по невнимание по време на наема' },
            { icon: '🔒', title: 'Кражба', desc: 'Доказана кражба на наетата вещ по вина на Наемателя' },
            { icon: '📦', title: 'Загуба', desc: 'Загуба на вещта при документирани обстоятелства' },
          ].map((item, i) => (
            <Card key={i}>
              <CardContent className="p-4 text-center">
                <div className="text-3xl mb-2">{item.icon}</div>
                <h3 className="font-semibold text-sm text-gray-800 mb-1">{item.title}</h3>
                <p className="text-xs text-gray-500 leading-relaxed">{item.desc}</p>
              </CardContent>
            </Card>
          ))}
        </div>
        <Card className="mt-3">
          <CardContent className="p-4 text-sm text-gray-600 leading-relaxed">
            <p>Максимално покритие: до <strong>80% от оценената стойност</strong> на артикула. Останалите 20% се покриват от депозита. Застраховката се предоставя от <strong>лицензиран застрахователен партньор</strong>, регистриран в България.</p>
          </CardContent>
        </Card>
        <p className="text-xs text-muted-foreground mt-3">* Изисква снимков доказателствен материал при предаване и при получаване.</p>
      </section>

      {/* How to file a claim */}
      <section className="mb-10">
        <h2 className="font-heading font-bold text-xl text-[#1e2a6e] mb-4">📋 Как да подам претенция?</h2>
        <Card>
          <CardContent className="p-5 space-y-3 text-sm text-gray-600">
            <div className="flex gap-3">
              <span className="w-7 h-7 rounded-full gradient-brand text-white flex items-center justify-center shrink-0 font-bold text-xs">1</span>
              <p>Направи снимки на вещта <strong>преди предаване и след получаване</strong> — това е твоята защита.</p>
            </div>
            <div className="flex gap-3">
              <span className="w-7 h-7 rounded-full gradient-brand text-white flex items-center justify-center shrink-0 font-bold text-xs">2</span>
              <p>При проблем при получаване — натисни <strong>„Докладвай проблем"</strong> в страницата на резервацията.</p>
            </div>
            <div className="flex gap-3">
              <span className="w-7 h-7 rounded-full gradient-brand text-white flex items-center justify-center shrink-0 font-bold text-xs">3</span>
              <p>Отвори <strong>спор</strong> с описание и качи доказателствен материал.</p>
            </div>
            <div className="flex gap-3">
              <span className="w-7 h-7 rounded-full gradient-brand text-white flex items-center justify-center shrink-0 font-bold text-xs">4</span>
              <p>Екипът на RentMe <strong>преглежда случая</strong> и взема решение в срок до 5 работни дни.</p>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Disclaimer */}
      <Card className="border-orange-200 bg-orange-50/50">
        <CardContent className="p-5 flex gap-3">
          <Info className="w-5 h-5 text-orange-500 shrink-0 mt-0.5" />
          <div className="text-sm text-gray-700 leading-relaxed">
            <p className="font-semibold mb-1">Важна бележка</p>
            <p>RentMe <strong>не е застрахователна компания</strong> и не предоставя застрахователни услуги по смисъла на Кодекса за застраховането. Описаната защита се предлага чрез <strong>лицензиран застрахователен партньор</strong>. За въпроси: <a href="mailto:stanislav@rentmemarket.com" className="text-primary hover:underline">stanislav@rentmemarket.com</a></p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}