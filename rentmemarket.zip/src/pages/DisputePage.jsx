import React, { useState, useEffect, useRef } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { ChevronLeft, AlertTriangle, Loader2, Flag, ImagePlus, X } from 'lucide-react';
import { isMobileDevice } from '@/components/common/QRPhotoUpload';
import QRPhotoUpload from '@/components/common/QRPhotoUpload';

const DISPUTE_REASONS = [
  { value: 'damage', label: 'Увредена вещ' },
  { value: 'not_as_described', label: 'Не отговаря на описанието' },
  { value: 'missing_item', label: 'Липсваща вещ / аксесоар' },
  { value: 'late_return', label: 'Закъсняло връщане' },
  { value: 'no_show', label: 'Не се е явил / не е изпратил' },
  { value: 'other', label: 'Друго' },
];

export default function DisputePage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [reason, setReason] = useState('');
  const [description, setDescription] = useState('');
  const [evidencePhotos, setEvidencePhotos] = useState([]);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef();

  useEffect(() => { base44.auth.me().then(setUser).catch(() => {}); }, []);

  const { data: booking, isLoading } = useQuery({
    queryKey: ['booking-dispute', id],
    queryFn: async () => {
      const bookings = await base44.entities.Booking.filter({ id });
      return bookings[0];
    },
    enabled: !!id,
  });

  const handlePhotoUpload = async (files) => {
    const remaining = 5 - evidencePhotos.length;
    const toUpload = Array.from(files).slice(0, remaining);
    if (!toUpload.length) return;
    setUploading(true);
    const uploaded = [];
    for (const file of toUpload) {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      uploaded.push(file_url);
    }
    setEvidencePhotos(prev => [...prev, ...uploaded]);
    setUploading(false);
  };

  const submitDispute = useMutation({
    mutationFn: async () => {
      await base44.entities.Booking.update(id, {
        status: 'disputed',
        dispute_reason: reason,
        dispute_description: description,
        dispute_opened_by: user.email,
        dispute_opened_at: new Date().toISOString(),
        dispute_evidence_photos: evidencePhotos,
      });
      // Notify the other party
      const otherEmail = user.email === booking.owner_email ? booking.renter_email : booking.owner_email;
      await base44.entities.Notification.create({
        user_email: otherEmail,
        type: 'dispute_update',
        title: 'Отворен е спор',
        message: `Спор е открит за наем: ${booking.listing_title}`,
        booking_id: id,
        link: `/booking/${id}`,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['booking-dispute', id] });
      toast.success('Спорът е подаден успешно.');
      navigate(`/booking/${id}`);
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!reason) { toast.error('Моля, избери причина.'); return; }
    if (description.length < 20) { toast.error('Описанието трябва да е поне 20 символа.'); return; }
    if (evidencePhotos.length < 1) { toast.error('Качи поне 1 снимка като доказателство.'); return; }
    submitDispute.mutate();
  };

  if (isLoading || !booking) {
    return <div className="flex items-center justify-center min-h-[50vh]"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>;
  }

  if (booking.status === 'disputed') {
    return (
      <div className="max-w-lg mx-auto px-4 py-12 text-center">
        <div className="w-16 h-16 bg-red-100 rounded-3xl flex items-center justify-center mx-auto mb-4">
          <Flag className="w-8 h-8 text-red-500" />
        </div>
        <h2 className="font-heading font-bold text-xl mb-2">Вече е открит спор</h2>
        <p className="text-muted-foreground text-sm mb-6">Спор за тази резервация вече е подаден и е под преглед.</p>
        <Link to={`/booking/${id}`}>
          <Button variant="outline"><ChevronLeft className="w-4 h-4 mr-1" /> Обратно към резервацията</Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-lg mx-auto px-4 py-8">
      <Link to={`/booking/${id}`} className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-6">
        <ChevronLeft className="w-4 h-4" /> Обратно
      </Link>

      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 bg-red-100 rounded-xl flex items-center justify-center">
          <AlertTriangle className="w-5 h-5 text-red-500" />
        </div>
        <div>
          <h1 className="font-heading font-bold text-xl">Отвори спор</h1>
          <p className="text-sm text-muted-foreground">{booking.listing_title}</p>
        </div>
      </div>

      <Card>
        <CardContent className="p-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <p className="font-semibold text-sm mb-3">Причина за спора *</p>
              <div className="space-y-2">
                {DISPUTE_REASONS.map(r => (
                  <label key={r.value} className={`flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-all ${reason === r.value ? 'border-[#7b2ff7] bg-[#7b2ff7]/5' : 'border-gray-200 hover:border-[#7b2ff7]/40'}`}>
                    <input
                      type="radio"
                      name="reason"
                      value={r.value}
                      checked={reason === r.value}
                      onChange={() => setReason(r.value)}
                      className="accent-[#7b2ff7]"
                    />
                    <span className="text-sm font-medium">{r.label}</span>
                  </label>
                ))}
              </div>
            </div>

            <div>
              <p className="font-semibold text-sm mb-2">Описание * <span className="text-muted-foreground font-normal">(мин. 20 символа)</span></p>
              <Textarea
                value={description}
                onChange={e => setDescription(e.target.value)}
                rows={4}
                placeholder="Опиши подробно какъв е проблемът..."
                className="resize-none"
              />
              <p className="text-xs text-muted-foreground mt-1">{description.length} символа</p>
            </div>

            <div>
              <p className="font-semibold text-sm mb-2">
                Качи снимки като доказателство *
                <span className="text-muted-foreground font-normal ml-1">(мин. 1 снимка)</span>
              </p>
              {!isMobileDevice() ? (
                <QRPhotoUpload onRefresh={() => window.location.reload()} />
              ) : (
                <>
                  <div className="grid grid-cols-3 gap-2 mb-2">
                    {evidencePhotos.map((url, i) => (
                      <div key={i} className="relative aspect-square rounded-xl overflow-hidden border border-gray-200">
                        <img src={url} alt="" className="w-full h-full object-cover" />
                        <button
                          type="button"
                          onClick={() => setEvidencePhotos(prev => prev.filter((_, j) => j !== i))}
                          className="absolute top-1 right-1 w-5 h-5 rounded-full bg-black/60 flex items-center justify-center text-white hover:bg-black/80"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                    {evidencePhotos.length < 5 && (
                      <button
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        disabled={uploading}
                        className="aspect-square rounded-xl border-2 border-dashed border-gray-300 flex flex-col items-center justify-center text-gray-400 hover:border-[#7b2ff7]/50 hover:text-[#7b2ff7] transition-colors"
                      >
                        {uploading ? <Loader2 className="w-5 h-5 animate-spin" /> : <ImagePlus className="w-5 h-5" />}
                        <span className="text-xs mt-1">{uploading ? 'Качва...' : 'Добави'}</span>
                      </button>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">{evidencePhotos.length}/5 снимки</p>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    capture="environment"
                    multiple
                    className="hidden"
                    onChange={e => handlePhotoUpload(e.target.files)}
                  />
                </>
              )}
            </div>

            <Button type="submit" disabled={submitDispute.isPending || uploading} className="w-full gradient-bg text-white border-0 gap-2">
              {submitDispute.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Flag className="w-4 h-4" />}
              Подай спор
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}