import { useEffect } from 'react';
import { base44 } from '@/api/base44Client';

export default function LoginRedirect() {
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const next = params.get('next') || '/';
    base44.auth.redirectToLogin(window.location.origin + next);
  }, []);

  return null;
}