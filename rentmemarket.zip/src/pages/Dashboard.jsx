import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Plus, Package, ShoppingBag, MessageSquare } from 'lucide-react';
import OwnerListingCard from '@/components/listings/OwnerListingCard';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

const statusColors = {
  requested: 'bg-yellow-100 text-yellow-700',
  approved: 'bg-blue-100 text-blue-700',
  payment_pending: 'bg-orange-100 text-orange-700',
  paid: 'bg-green-100 text-green-700',
  item_sent: 'bg-purple-100 text-purple-700',
  item_received: 'bg-blue-100 text-blue-700',
  active: 'bg-primary/10 text-primary',
  returning: 'bg-yellow-100 text-yellow-700',
  returned: 'bg-green-100 text-green-700',
  completed: 'bg-gray-100 text-gray-700',
  disputed: 'bg-red-100 text-red-700',
  cancelled: 'bg-red-100 text-red-700',
  expired: 'bg-gray-100 text-gray-700',
};

const statusLabels = {
  requested: 'Заявена', approved: 'Одобрена', payment_pending: 'Изчакване плащане',
  paid: 'Платена', item_sent: 'Изпратен', item_received: 'Получен', active: 'Активна',
  returning: 'Връщане', returned: 'Върнат', completed: 'Завършена',
  disputed: 'Спор', cancelled: 'Отказана', expired: 'Изтекла',
};

export default function Dashboard() {
  const [user, setUser] = useState(null);
  const [activeTab, setActiveTab] = useState('listings');

  useEffect(() => { base44.auth.me().then(setUser).catch(() => {}); }, []);

  const { data: myListings = [], isLoading } = useQuery({
    queryKey: ['my-listings', user?.email],
    queryFn: () => base44.entities.Listing.filter({ owner_email: user.email }, '-created_date', 50),
    enabled: !!user?.email,
    initialData: [],
  });

  const { data: pendingBookings = [] } = useQuery({
    queryKey: ['pending-bookings-owner', user?.email],
    queryFn: () => base44.entities.Booking.filter({ owner_email: user.email, status: 'requested' }, '-created_date', 100),
    enabled: !!user?.email,
    initialData: [],
  });

  const { data: myRentals = [], isLoading: rentalsLoading } = useQuery({
    queryKey: ['my-rentals', user?.email],
    queryFn: () => base44.entities.Booking.filter({ renter_email: user.email }, '-created_date', 50),
    enabled: !!user?.email,
    initialData: [],
  });

  const pendingByListing = pendingBookings.reduce((acc, b) => {
    acc[b.listing_id] = (acc[b.listing_id] || 0) + 1;
    return acc;
  }, {});

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 py-8 pb-28 md:pb-10">

      {/* Header */}
      <div className="flex items-center justify-between mb-7">
        <div>
          <h1 className="font-heading text-2xl font-bold text-gray-900">Моят профил</h1>
          <p className="text-gray-400 text-sm mt-0.5">Управлявай обявите и наемите си</p>
        </div>
        <Link to="/create-listing">
          <button className="flex items-center gap-2 px-4 py-2.5 rounded-xl gradient-brand text-white font-semibold text-sm shadow-brand hover:opacity-90 transition-opacity">
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">Качи нова вещ</span>
            <span className="sm:hidden">Нова</span>
          </button>
        </Link>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 p-1 bg-gray-100 rounded-2xl mb-6">
        <button
          onClick={() => setActiveTab('listings')}
          className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-semibold transition-all ${activeTab === 'listings' ? 'bg-white shadow-sm text-[#7b2ff7]' : 'text-gray-500 hover:text-gray-700'}`}
        >
          <Package className="w-4 h-4" /> Моите обяви
        </button>
        <button
          onClick={() => setActiveTab('rentals')}
          className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-semibold transition-all ${activeTab === 'rentals' ? 'bg-white shadow-sm text-[#7b2ff7]' : 'text-gray-500 hover:text-gray-700'}`}
        >
          <ShoppingBag className="w-4 h-4" /> Моите наема
          {myRentals.filter(b => !['completed','cancelled','expired'].includes(b.status)).length > 0 && (
            <span className="ml-1 w-5 h-5 rounded-full bg-[#7b2ff7] text-white text-xs flex items-center justify-center">
              {myRentals.filter(b => !['completed','cancelled','expired'].includes(b.status)).length}
            </span>
          )}
        </button>
      </div>

      {/* Listings Tab */}
      {activeTab === 'listings' && (
        isLoading ? (
          <div className="space-y-5">
            {[1, 2, 3].map(i => (
              <div key={i} className="bg-white rounded-3xl overflow-hidden border border-gray-100">
                <Skeleton className="w-full h-52" />
                <div className="p-5 space-y-3">
                  <Skeleton className="h-5 w-3/4" />
                  <Skeleton className="h-4 w-1/3" />
                  <Skeleton className="h-11 w-full rounded-2xl" />
                </div>
              </div>
            ))}
          </div>
        ) : myListings.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <div className="w-20 h-20 bg-purple-50 rounded-3xl flex items-center justify-center mb-5">
              <Package className="w-10 h-10 text-[#7b2ff7]/40" />
            </div>
            <h2 className="font-heading font-bold text-gray-800 text-lg mb-2">Нямаш качени обяви</h2>
            <p className="text-gray-400 text-sm mb-6 max-w-xs">
              Качи първата си вещ и започни да печелиш от неща, които не използваш.
            </p>
            <Link to="/create-listing">
              <button className="px-6 py-3 rounded-2xl gradient-brand text-white font-semibold text-sm shadow-brand hover:opacity-90 transition-opacity">
                Качи първата си вещ
              </button>
            </Link>
          </div>
        ) : (
          <div className="space-y-5">
            {myListings.map((listing, i) => (
              <OwnerListingCard
                key={listing.id}
                listing={listing}
                pendingCount={pendingByListing[listing.id] || 0}
                index={i}
              />
            ))}
          </div>
        )
      )}

      {/* Rentals Tab */}
      {activeTab === 'rentals' && (
        rentalsLoading ? (
          <div className="space-y-3">
            {[1, 2, 3].map(i => <Skeleton key={i} className="h-20 w-full rounded-2xl" />)}
          </div>
        ) : myRentals.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <div className="w-20 h-20 bg-purple-50 rounded-3xl flex items-center justify-center mb-5">
              <ShoppingBag className="w-10 h-10 text-[#7b2ff7]/40" />
            </div>
            <h2 className="font-heading font-bold text-gray-800 text-lg mb-2">Нямаш активни наема</h2>
            <p className="text-gray-400 text-sm mb-6 max-w-xs">Намери нещо интересно за наемане!</p>
            <Link to="/browse">
              <button className="px-6 py-3 rounded-2xl gradient-brand text-white font-semibold text-sm shadow-brand hover:opacity-90 transition-opacity">
                Разгледай обяви
              </button>
            </Link>
          </div>
        ) : (
          <div className="space-y-3">
            {myRentals.map(booking => (
              <Link key={booking.id} to={`/booking/${booking.id}`} className="block">
                <div className="bg-white rounded-2xl border border-gray-100 p-4 flex items-center gap-4 hover:shadow-card-hover transition-all hover:-translate-y-0.5">
                  <img
                    src={booking.listing_image || 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=100&h=80&fit=crop'}
                    alt={booking.listing_title}
                    className="w-16 h-14 rounded-xl object-cover shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-gray-800 text-sm truncate">{booking.listing_title}</p>
                    <p className="text-xs text-gray-400 mt-0.5">{booking.start_date} → {booking.end_date}</p>
                  </div>
                  <div className="flex flex-col items-end gap-2 shrink-0">
                    <Badge className={`${statusColors[booking.status]} text-xs`}>
                      {statusLabels[booking.status] || booking.status}
                    </Badge>
                    <Link
                      to={`/listing/${booking.listing_id}/chat`}
                      onClick={e => e.stopPropagation()}
                      className="flex items-center gap-1 text-xs text-[#7b2ff7] font-semibold hover:underline"
                    >
                      <MessageSquare className="w-3 h-3" /> Чат
                    </Link>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )
      )}
    </div>
  );
}