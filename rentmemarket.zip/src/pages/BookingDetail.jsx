import React, { useState, useEffect, useCallback } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useI18n } from '@/lib/i18n';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';
import ReviewForm from '@/components/bookings/ReviewForm';
import PhotoUploadModal from '@/components/bookings/PhotoUploadModal';
import {
  ChevronLeft, Check, X, CreditCard, PackageCheck, AlertTriangle,
  MessageSquare, Loader2, Flag, Camera
} from 'lucide-react';

const statusColors = {
  requested: 'bg-yellow-100 text-yellow-700',
  approved: 'bg-blue-100 text-blue-700',
  payment_pending: 'bg-orange-100 text-orange-700',
  paid: 'bg-green-100 text-green-700',
  item_sent: 'bg-purple-100 text-purple-700',
  item_received: 'bg-blue-100 text-blue-700',
  active: 'bg-primary/10 text-primary',
  returning: 'bg-yellow-100 text-yellow-700',
  returned: 'bg-green-100 text-green-700',
  completed: 'bg-gray-100 text-gray-700',
  disputed: 'bg-red-100 text-red-700',
  cancelled: 'bg-red-100 text-red-700',
  expired: 'bg-gray-100 text-gray-700',
};

const statusLabels = {
  bg: {
    requested: 'Заявена', approved: 'Одобрена', payment_pending: 'Плащане',
    paid: 'Платена', item_sent: 'Изпратен', item_received: 'Получен',
    active: 'Активна', returning: 'Връщане', returned: 'Върнат',
    completed: 'Завършена', disputed: 'Спор', cancelled: 'Отказана', expired: 'Изтекла',
  },
  en: {
    requested: 'Requested', approved: 'Approved', payment_pending: 'Payment',
    paid: 'Paid', item_sent: 'Sent', item_received: 'Received',
    active: 'Active', returning: 'Returning', returned: 'Returned',
    completed: 'Completed', disputed: 'Disputed', cancelled: 'Cancelled', expired: 'Expired',
  }
};

async function sendNotification(userEmail, type, title, message, bookingId) {
  await base44.entities.Notification.create({
    user_email: userEmail,
    type,
    title,
    message,
    link: `/booking/${bookingId}`,
    booking_id: bookingId,
  });
}

export default function BookingDetail() {
  const { id } = useParams();
  const { t, lang } = useI18n();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [showReceiptModal, setShowReceiptModal] = useState(false);
  const [showReturnModal, setShowReturnModal] = useState(false);

  useEffect(() => { base44.auth.me().then(setUser).catch(() => {}); }, []);

  const { data: booking, isLoading, refetch: refetchBooking } = useQuery({
    queryKey: ['booking', id],
    queryFn: async () => {
      const bookings = await base44.entities.Booking.filter({ id });
      return bookings[0];
    },
    enabled: !!id,
  });

  const { data: renterProfile } = useQuery({
    queryKey: ['renter-reviews', booking?.renter_email],
    queryFn: async () => {
      const reviews = await base44.entities.Review.filter({ reviewee_email: booking.renter_email, type: 'owner_to_renter' });
      if (!reviews.length) return null;
      const avg = reviews.reduce((s, r) => s + r.rating, 0) / reviews.length;
      return { rating_avg: avg, rating_count: reviews.length };
    },
    enabled: !!booking?.renter_email && user?.email === booking?.owner_email,
  });

  const { data: myReview, refetch: refetchReview } = useQuery({
    queryKey: ['booking-review', id, user?.email],
    queryFn: async () => {
      const reviews = await base44.entities.Review.filter({ booking_id: id, reviewer_email: user?.email });
      return reviews[0];
    },
    enabled: !!id && !!user?.email,
  });

  const sendEmail = (templateKey, to, params) =>
    base44.functions.invoke('sendBookingEmail', { templateKey, to, params }).catch(() => {});

  const updateBooking = useMutation({
    mutationFn: async ({ status, extra, notifyEmail, notifyType, notifyTitle, notifyMsg, emailKey, emailTo, emailParams, emailKey2, emailTo2, emailParams2 }) => {
      await base44.entities.Booking.update(id, { status, ...extra });
      if (notifyEmail) {
        await sendNotification(notifyEmail, notifyType, notifyTitle, notifyMsg, id);
      }
      if (emailKey && emailTo) {
        await sendEmail(emailKey, emailTo, { bookingId: id, ...emailParams });
      }
      if (emailKey2 && emailTo2) {
        await sendEmail(emailKey2, emailTo2, { bookingId: id, ...emailParams2 });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['booking', id] });
      toast.success(lang === 'bg' ? 'Обновено!' : 'Updated!');
    },
  });

  if (isLoading || !booking) {
    return <div className="flex items-center justify-center min-h-[50vh]"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>;
  }

  const isOwner = user?.email === booking.owner_email;
  const isRenter = user?.email === booking.renter_email;
  const isBg = lang === 'bg';

  const statusSteps = [
    { key: 'requested', label: isBg ? 'Заявена' : 'Requested' },
    { key: 'approved', label: isBg ? 'Одобрена' : 'Approved' },
    { key: 'paid', label: isBg ? 'Платена' : 'Paid' },
    { key: 'item_sent', label: isBg ? 'Изпратен' : 'Sent' },
    { key: 'active', label: isBg ? 'Активна' : 'Active' },
    { key: 'returning', label: isBg ? 'Връщане' : 'Returning' },
    { key: 'completed', label: isBg ? 'Завършена' : 'Completed' },
  ];

  // Map item_received → active for progress bar display
  const displayStatus = booking.status === 'item_received' ? 'active' : booking.status;
  const currentStepIdx = statusSteps.findIndex(s => s.key === displayStatus);

  const statusLabel = (statusLabels[lang] || statusLabels.bg)[booking.status] || booking.status;

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
      <Link to="/dashboard" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-6">
        <ChevronLeft className="w-4 h-4" /> {isBg ? 'Обратно' : 'Back'}
      </Link>

      <div className="flex items-start justify-between mb-6">
        <div>
          <h1 className="font-heading text-2xl font-bold">{booking.listing_title}</h1>
          <p className="text-sm text-muted-foreground mt-1">
            {booking.start_date} → {booking.end_date} • {booking.total_days} {isBg ? 'дни' : 'days'}
          </p>
        </div>
        <Badge className={`${statusColors[booking.status]} text-sm px-3 py-1`}>
          {statusLabel}
        </Badge>
      </div>

      {/* Progress */}
      <div className="mb-8 overflow-x-auto">
        <div className="flex items-center min-w-[500px]">
          {statusSteps.map((step, i) => (
            <React.Fragment key={step.key}>
              <div className="flex flex-col items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
                  i <= currentStepIdx ? 'gradient-bg text-white' : 'bg-muted text-muted-foreground'
                }`}>
                  {i < currentStepIdx ? <Check className="w-4 h-4" /> : i + 1}
                </div>
                <span className={`text-[10px] mt-1 whitespace-nowrap ${i <= currentStepIdx ? 'text-foreground font-medium' : 'text-muted-foreground'}`}>
                  {step.label}
                </span>
              </div>
              {i < statusSteps.length - 1 && (
                <div className={`flex-1 h-0.5 mx-2 ${i < currentStepIdx ? 'gradient-bg' : 'bg-muted'}`} />
              )}
            </React.Fragment>
          ))}
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {/* Main content */}
        <div className="md:col-span-2 space-y-4">
          {/* Listing info */}
          <Card>
            <CardContent className="p-4 flex gap-4">
              <img src={booking.listing_image || 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=200&h=150&fit=crop'} alt="" className="w-24 h-20 rounded-lg object-cover" />
              <div>
                <h3 className="font-semibold">{booking.listing_title}</h3>
                <div className="flex items-center gap-1.5 flex-wrap">
                  <p className="text-sm text-muted-foreground">
                    {isOwner
                      ? `${isBg ? 'Наемател' : 'Renter'}: ${booking.renter_name}`
                      : `${isBg ? 'Собственик' : 'Owner'}: ${booking.owner_name}`}
                  </p>
                  {isOwner && renterProfile?.rating_avg >= 4.8 && renterProfile?.rating_count >= 3 && (
                    <span className="text-[10px] bg-green-100 text-green-700 px-1.5 py-0.5 rounded-full font-semibold">Доверен наемател ✓</span>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* STEP 1 — Owner: approve/reject */}
          {booking.status === 'requested' && isOwner && (
            <Card className="border-yellow-200 bg-yellow-50/50">
              <CardContent className="p-4">
                <h3 className="font-semibold mb-3">{isBg ? 'Имате нова заявка!' : 'New booking request!'}</h3>
                <div className="flex gap-3">
                  <Button
                    onClick={() => updateBooking.mutate({
                      status: 'approved',
                      notifyEmail: booking.renter_email,
                      notifyType: 'booking_approved',
                      notifyTitle: isBg ? 'Заявката е одобрена!' : 'Booking approved!',
                      notifyMsg: isBg
                        ? `"${booking.listing_title}" е одобрена. Моля, завърши плащането.`
                        : `"${booking.listing_title}" was approved. Please complete payment.`,
                      emailKey: 'booking_approved',
                      emailTo: booking.renter_email,
                      emailParams: { ownerName: booking.owner_name, listingTitle: booking.listing_title },
                    })}
                    className="gradient-bg text-white border-0 gap-1"
                    disabled={updateBooking.isPending}
                  >
                    <Check className="w-4 h-4" /> {isBg ? 'Одобри' : 'Approve'}
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => updateBooking.mutate({
                      status: 'cancelled',
                      extra: { cancelled_by: user.email, cancellation_reason: 'Owner rejected' },
                      notifyEmail: booking.renter_email,
                      notifyType: 'booking_rejected',
                      notifyTitle: isBg ? 'Заявката е отказана' : 'Booking rejected',
                      notifyMsg: isBg
                        ? `Заявката за "${booking.listing_title}" беше отказана.`
                        : `Your request for "${booking.listing_title}" was rejected.`,
                      emailKey: 'booking_rejected',
                      emailTo: booking.renter_email,
                      emailParams: { ownerName: booking.owner_name, listingTitle: booking.listing_title },
                    })}
                    disabled={updateBooking.isPending}
                  >
                    <X className="w-4 h-4 mr-1" /> {isBg ? 'Откажи' : 'Reject'}
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* STEP 2 — Renter: pay */}
          {booking.status === 'approved' && isRenter && (
            <Card className="border-blue-200 bg-blue-50/50">
              <CardContent className="p-4">
                <h3 className="font-semibold mb-2">{isBg ? 'Заявката е одобрена!' : 'Request approved!'}</h3>
                <p className="text-sm text-muted-foreground mb-3">
                  {isBg ? 'Моля, завършете плащането в рамките на 30 минути.' : 'Please complete payment within 30 minutes.'}
                </p>
                <Button
                  onClick={() => updateBooking.mutate({
                    status: 'paid',
                    notifyEmail: booking.owner_email,
                    notifyType: 'payment_success',
                    notifyTitle: isBg ? 'Плащането е получено!' : 'Payment received!',
                    notifyMsg: isBg
                      ? `${booking.renter_name} плати за "${booking.listing_title}". Подгответе артикула.`
                      : `${booking.renter_name} paid for "${booking.listing_title}". Please prepare the item.`,
                    emailKey: 'payment_received',
                    emailTo: booking.owner_email,
                    emailParams: { renterName: booking.renter_name, listingTitle: booking.listing_title },
                  })}
                  className="gradient-bg text-white border-0 gap-1"
                  disabled={updateBooking.isPending}
                >
                  <CreditCard className="w-4 h-4" /> {isBg ? 'Плати' : 'Pay'} {booking.total_amount?.toFixed(0)} €
                </Button>
              </CardContent>
            </Card>
          )}

          {/* STEP 3 — Owner: mark as sent */}
          {booking.status === 'paid' && isOwner && (
            <Card className="border-green-200 bg-green-50/50">
              <CardContent className="p-4">
                <h3 className="font-semibold mb-2">{isBg ? 'Плащането е получено!' : 'Payment received!'}</h3>
                <p className="text-sm text-muted-foreground mb-3">
                  {isBg ? 'Подгответе и изпратете артикула.' : 'Prepare and send the item.'}
                </p>
                <Button
                  onClick={() => updateBooking.mutate({
                    status: 'item_sent',
                    notifyEmail: booking.renter_email,
                    notifyType: 'item_sent',
                    notifyTitle: isBg ? 'Артикулът е изпратен!' : 'Item shipped!',
                    notifyMsg: isBg
                      ? `${booking.owner_name} изпрати "${booking.listing_title}". Очаквай го скоро.`
                      : `${booking.owner_name} sent "${booking.listing_title}". Expect it soon.`,
                    emailKey: 'item_sent',
                    emailTo: booking.renter_email,
                    emailParams: { ownerName: booking.owner_name, listingTitle: booking.listing_title },
                  })}
                  className="gradient-bg text-white border-0 gap-1"
                  disabled={updateBooking.isPending}
                >
                  <PackageCheck className="w-4 h-4" /> {isBg ? 'Маркирай като изпратен' : 'Mark as Sent'}
                </Button>
              </CardContent>
            </Card>
          )}

          {/* STEP 4 — Renter: confirm receipt (with photo upload) */}
          {booking.status === 'item_sent' && isRenter && (
            <Card className="border-purple-200 bg-purple-50/50">
              <CardContent className="p-4">
                <h3 className="font-semibold mb-2">{isBg ? 'Получи ли артикула?' : 'Did you receive the item?'}</h3>
                <div className="flex gap-3">
                  <Button
                    onClick={() => setShowReceiptModal(true)}
                    className="gradient-bg text-white border-0 gap-1"
                    disabled={updateBooking.isPending}
                  >
                    <Camera className="w-4 h-4" /> {isBg ? 'Всичко е наред' : 'All Good'}
                  </Button>
                  <Button
                    variant="destructive"
                    onClick={() => navigate(`/dispute/${booking.id}`)}
                    disabled={updateBooking.isPending}
                  >
                    <AlertTriangle className="w-4 h-4 mr-1" /> {isBg ? 'Докладвай проблем' : 'Report Issue'}
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Photos taken at receipt — visible to both parties */}
          {booking.condition_photos_received?.length > 0 && (
            <Card>
              <CardContent className="p-4">
                <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
                  <Camera className="w-4 h-4 text-primary" />
                  {isBg ? 'Снимки при получаване' : 'Photos at receipt'}
                </h4>
                <div className="grid grid-cols-3 gap-2">
                  {booking.condition_photos_received.map((url, i) => (
                    <a key={i} href={url} target="_blank" rel="noopener noreferrer">
                      <img src={url} alt="" className="aspect-square rounded-lg object-cover w-full border border-gray-200 hover:opacity-80 transition-opacity" />
                    </a>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* STEP 5 — Renter: initiate return (with photo upload) */}
          {booking.status === 'active' && isRenter && (
            <Card className="border-primary/20 bg-primary/5">
              <CardContent className="p-4">
                <h3 className="font-semibold mb-2">{isBg ? 'Наемането е активно' : 'Rental is active'}</h3>
                <Button
                  onClick={() => setShowReturnModal(true)}
                  variant="outline"
                  className="gap-1"
                  disabled={updateBooking.isPending}
                >
                  <Camera className="w-4 h-4" /> {isBg ? 'Започни връщане' : 'Initiate Return'}
                </Button>
              </CardContent>
            </Card>
          )}

          {/* STEP 6 — Owner: confirm return — show renter's return photos first */}
          {booking.status === 'returning' && isOwner && (
            <Card className="border-green-200 bg-green-50/50">
              <CardContent className="p-4">
                <h3 className="font-semibold mb-3">{isBg ? 'Артикулът се връща' : 'Item is being returned'}</h3>
                {booking.condition_photos_return?.length > 0 ? (
                  <>
                    <p className="text-sm text-muted-foreground mb-3">
                      {isBg ? 'Снимки от наемателя преди връщане:' : "Renter's photos before return:"}
                    </p>
                    <div className="grid grid-cols-3 gap-2 mb-4">
                      {booking.condition_photos_return.map((url, i) => (
                        <a key={i} href={url} target="_blank" rel="noopener noreferrer">
                          <img src={url} alt="" className="aspect-square rounded-lg object-cover w-full border border-gray-200 hover:opacity-80 transition-opacity" />
                        </a>
                      ))}
                    </div>
                  </>
                ) : (
                  <p className="text-sm text-amber-600 mb-3">
                    {isBg ? 'Наемателят не е качил снимки при връщане.' : 'Renter did not upload return photos.'}
                  </p>
                )}
                <div className="flex gap-3">
                  <Button
                    onClick={() => updateBooking.mutate({
                      status: 'completed',
                      extra: { owner_return_status: 'all_good' },
                      notifyEmail: booking.renter_email,
                      notifyType: 'payout',
                      notifyTitle: isBg ? 'Наемът е завършен!' : 'Rental completed!',
                      notifyMsg: isBg
                        ? `"${booking.listing_title}" беше върнат. Депозитът ти ще бъде освободен.`
                        : `"${booking.listing_title}" was returned. Your deposit will be released.`,
                      emailKey: 'booking_completed_renter',
                      emailTo: booking.renter_email,
                      emailParams: { listingTitle: booking.listing_title },
                      emailKey2: 'booking_completed_owner',
                      emailTo2: booking.owner_email,
                      emailParams2: { listingTitle: booking.listing_title },
                    })}
                    className="gradient-bg text-white border-0 gap-1"
                    disabled={updateBooking.isPending}
                  >
                    <Check className="w-4 h-4" /> {isBg ? 'Потвърди връщане' : 'Confirm Return'}
                  </Button>
                  <Button
                    variant="destructive"
                    onClick={() => navigate(`/dispute/${booking.id}`)}
                    disabled={updateBooking.isPending}
                  >
                    <AlertTriangle className="w-4 h-4 mr-1" /> {isBg ? 'Докладвай проблем' : 'Report Issue'}
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Return photos visible to both parties */}
          {booking.condition_photos_return?.length > 0 && booking.status !== 'returning' && (
            <Card>
              <CardContent className="p-4">
                <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
                  <Camera className="w-4 h-4 text-primary" />
                  {isBg ? 'Снимки преди връщане' : 'Photos before return'}
                </h4>
                <div className="grid grid-cols-3 gap-2">
                  {booking.condition_photos_return.map((url, i) => (
                    <a key={i} href={url} target="_blank" rel="noopener noreferrer">
                      <img src={url} alt="" className="aspect-square rounded-lg object-cover w-full border border-gray-200 hover:opacity-80 transition-opacity" />
                    </a>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Photo modals */}
          <PhotoUploadModal
            open={showReceiptModal}
            onClose={() => setShowReceiptModal(false)}
            onRefresh={refetchBooking}
            title="Качи снимки на вещта при получаване"
            warning="Снимките защитават депозита ти при евентуален спор"
            confirmLabel="Потвърди получаването"
            minPhotos={1}
            maxPhotos={5}
            onConfirm={async (photos) => {
              await updateBooking.mutateAsync({
                status: 'active',
                extra: { renter_receipt_status: 'all_good', condition_photos_received: photos },
                notifyEmail: booking.owner_email,
                notifyType: 'item_received',
                notifyTitle: 'Артикулът е получен!',
                notifyMsg: `${booking.renter_name} потвърди получаването на "${booking.listing_title}".`,
              });
            }}
          />
          <PhotoUploadModal
            open={showReturnModal}
            onClose={() => setShowReturnModal(false)}
            onRefresh={refetchBooking}
            title="Качи снимки на вещта преди връщане"
            warning="Снимките защитават депозита ти при евентуален спор"
            confirmLabel="Започни връщане"
            minPhotos={1}
            maxPhotos={5}
            onConfirm={async (photos) => {
              await updateBooking.mutateAsync({
                status: 'returning',
                extra: { condition_photos_return: photos },
                notifyEmail: booking.owner_email,
                notifyType: 'return_reminder',
                notifyTitle: 'Артикулът се връща',
                notifyMsg: `${booking.renter_name} започна връщането на "${booking.listing_title}".`,
              });
            }}
          />

          {/* Completed state */}
          {booking.status === 'completed' && (
            <Card className="border-green-200 bg-green-50/50">
              <CardContent className="p-4 text-center">
                <div className="text-3xl mb-2">🎉</div>
                <h3 className="font-semibold text-green-700">{isBg ? 'Наемът е завършен успешно!' : 'Rental completed successfully!'}</h3>
                {!myReview && <p className="text-sm text-muted-foreground mt-1">{isBg ? 'Остави рецензия по-долу.' : 'Leave a review below.'}</p>}
              </CardContent>
            </Card>
          )}
        </div>

        {/* Sidebar */}
        <div>
          <Card className="sticky top-24">
            <CardHeader>
              <CardTitle className="text-lg">{isBg ? 'Обобщение' : 'Summary'}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between text-sm">
                <span>{booking.daily_price?.toFixed(0)} € × {booking.total_days} {isBg ? 'дни' : 'days'}</span>
                <span>{booking.rental_total?.toFixed(0)} €</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>{isBg ? 'Такса платформа' : 'Platform fee'}</span>
                <span>{booking.platform_fee?.toFixed(0)} €</span>
              </div>
              <div className="flex justify-between text-sm text-muted-foreground">
                <span>{isBg ? 'Депозит (задържан)' : 'Deposit (held)'}</span>
                <span>{booking.deposit_amount?.toFixed(0)} €</span>
              </div>
              {booking.insurance_amount > 0 && (
                <div className="flex justify-between text-sm">
                  <span>{isBg ? 'Застраховка' : 'Insurance'}</span>
                  <span>{booking.insurance_amount?.toFixed(0)} €</span>
                </div>
              )}
              <Separator />
              <div className="flex justify-between font-bold">
                <span>{isBg ? 'Общо' : 'Total'}</span>
                <span className="gradient-text">{booking.total_amount?.toFixed(0)} €</span>
              </div>
            </CardContent>
          </Card>

          <div className="mt-4 flex flex-col gap-2">
            <Link to={`/messages?booking=${booking.id}`}>
              <Button variant="outline" className="w-full gap-2">
                <MessageSquare className="w-4 h-4" /> {isBg ? 'Чат' : 'Chat'}
              </Button>
            </Link>
            {['active', 'returning', 'returned'].includes(booking.status) && (
              <Link to={`/dispute/${booking.id}`}>
                <Button variant="ghost" className="w-full gap-2 text-destructive">
                  <Flag className="w-4 h-4" /> {isBg ? 'Отвори спор' : 'Open Dispute'}
                </Button>
              </Link>
            )}
          </div>

          {/* Reviews — both parties can review after completion */}
          {booking.status === 'completed' && !myReview && (
            <div className="mt-4">
              <ReviewForm
                booking={booking}
                reviewerEmail={user?.email}
                reviewerName={user?.full_name}
                isOwner={isOwner}
                onSuccess={() => { refetchBooking(); refetchReview(); }}
              />
            </div>
          )}

          {myReview && (
            <Card className="mt-4 bg-green-50/50 border-green-200">
              <CardContent className="p-4">
                <p className="text-sm font-semibold text-green-700 mb-2">✓ {isBg ? 'Вече оставихте рецензия' : 'You already left a review'}</p>
                <div className="flex items-center gap-1">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <span key={i} className="text-lg">{i < myReview.rating ? '⭐' : '☆'}</span>
                  ))}
                </div>
                {myReview.comment && <p className="text-sm text-gray-600 mt-2">{myReview.comment}</p>}
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}