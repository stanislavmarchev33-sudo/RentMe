import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useI18n } from '@/lib/i18n';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { toast } from 'sonner';
import { User, Bell, Globe, Shield, Save, Loader2, ShieldCheck, Clock, CheckCircle2, XCircle } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Settings() {
  const { lang, switchLang } = useI18n();
  const [user, setUser] = useState(null);
  const [saving, setSaving] = useState(false);
  const [profile, setProfile] = useState({ phone: '', city: '', bio: '' });
  const [kyc, setKyc] = useState(null);

  useEffect(() => {
    base44.auth.me().then(async u => {
      setUser(u);
      setProfile({ phone: u.phone || '', city: u.city || '', bio: u.bio || '' });
      const kycs = await base44.entities.KYCVerification.filter({ user_email: u.email });
      setKyc(kycs[0] || null);
    }).catch(() => {});
  }, []);

  const saveProfile = async () => {
    setSaving(true);
    await base44.auth.updateMe(profile);
    toast.success(lang === 'bg' ? 'Запазено!' : 'Saved!');
    setSaving(false);
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8">
      <h1 className="font-heading text-2xl md:text-3xl font-bold mb-8">
        {lang === 'bg' ? 'Настройки' : 'Settings'}
      </h1>

      <div className="space-y-6">
        {/* Profile */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="w-5 h-5" /> {lang === 'bg' ? 'Профил' : 'Profile'}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>{lang === 'bg' ? 'Име' : 'Name'}</Label>
              <Input value={user?.full_name || ''} disabled className="mt-1 bg-muted" />
            </div>
            <div>
              <Label>Email</Label>
              <Input value={user?.email || ''} disabled className="mt-1 bg-muted" />
            </div>
            <div>
              <Label>{lang === 'bg' ? 'Телефон' : 'Phone'}</Label>
              <Input value={profile.phone} onChange={e => setProfile({...profile, phone: e.target.value})} className="mt-1" />
            </div>
            <div>
              <Label>{lang === 'bg' ? 'Град' : 'City'}</Label>
              <Input value={profile.city} onChange={e => setProfile({...profile, city: e.target.value})} className="mt-1" />
            </div>
            <Button onClick={saveProfile} disabled={saving} className="gradient-bg text-white border-0 gap-2">
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
              {lang === 'bg' ? 'Запази' : 'Save'}
            </Button>
          </CardContent>
        </Card>

        {/* KYC Verification */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5" /> Верификация на самоличност
            </CardTitle>
          </CardHeader>
          <CardContent>
            {!kyc && (
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <XCircle className="w-5 h-5 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">Неверифициран</span>
                </div>
                <Link to="/verify">
                  <Button size="sm" className="gradient-bg text-white border-0">Верифицирай се сега</Button>
                </Link>
              </div>
            )}
            {kyc?.status === 'pending' && (
              <div className="flex items-center gap-2 text-yellow-700">
                <Clock className="w-5 h-5" />
                <span className="text-sm font-medium">В процес на проверка</span>
              </div>
            )}
            {kyc?.status === 'approved' && (
              <div className="flex items-center gap-2 text-green-700">
                <CheckCircle2 className="w-5 h-5" />
                <span className="text-sm font-medium">Верифициран ✅</span>
              </div>
            )}
            {kyc?.status === 'rejected' && (
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-red-600">
                  <XCircle className="w-5 h-5" />
                  <span className="text-sm font-medium">Отхвърлено</span>
                </div>
                <Link to="/verify">
                  <Button size="sm" variant="outline">Опитай отново</Button>
                </Link>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Language */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Globe className="w-5 h-5" /> {lang === 'bg' ? 'Език' : 'Language'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-3">
              <Button variant={lang === 'bg' ? 'default' : 'outline'} onClick={() => switchLang('bg')}>🇧🇬 Български</Button>
              <Button variant={lang === 'en' ? 'default' : 'outline'} onClick={() => switchLang('en')}>🇬🇧 English</Button>
            </div>
          </CardContent>
        </Card>

        {/* Notifications */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bell className="w-5 h-5" /> {lang === 'bg' ? 'Известия' : 'Notifications'}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm">{lang === 'bg' ? 'Email известия' : 'Email notifications'}</span>
              <Switch defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">{lang === 'bg' ? 'Известия за нови заявки' : 'New request notifications'}</span>
              <Switch defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">{lang === 'bg' ? 'Маркетинг' : 'Marketing'}</span>
              <Switch />
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}