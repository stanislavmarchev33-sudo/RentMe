import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { getOrCreateChatThread, getOrCreateListingThread } from '@/lib/chatUtils';
import ChatSidebar from '@/components/chat/ChatSidebar';
import ChatConversation, { ChatEmptyState } from '@/components/chat/ChatConversation';

export default function Messages() {
  const [user, setUser] = useState(null);
  const [selectedThread, setSelectedThread] = useState(null);
  const [showChat, setShowChat] = useState(false);

  useEffect(() => { base44.auth.me().then(setUser).catch(() => {}); }, []);

  const { data: threads = [], refetch: refetchThreads } = useQuery({
    queryKey: ['chat-threads', user?.email],
    queryFn: () => base44.entities.ChatThread.list('-updated_date', 100),
    enabled: !!user?.email,
    refetchInterval: 3000,
  });

  const { data: activeBooking } = useQuery({
    queryKey: ['booking-for-chat', selectedThread?.booking_id],
    queryFn: async () => {
      const res = await base44.entities.Booking.filter({ id: selectedThread.booking_id });
      return res[0] || null;
    },
    enabled: !!selectedThread?.booking_id,
  });

  // Auto-select from ?booking= or ?listing= URL param
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const bookingId = params.get('booking');
    const listingId = params.get('listing');
    if (!user || (!bookingId && !listingId)) return;

    if (bookingId) {
      const match = threads.find((t) => t.booking_id === bookingId);
      if (match) { setSelectedThread(match); setShowChat(true); return; }
      base44.entities.Booking.filter({ id: bookingId }).then(async (res) => {
        const booking = res[0];
        if (booking) {
          const thread = await getOrCreateChatThread(booking);
          setSelectedThread(thread);
          setShowChat(true);
        }
      }).catch(() => {});
    } else if (listingId) {
      base44.entities.Listing.filter({ id: listingId }).then(async (res) => {
        const listing = res[0];
        if (!listing || user.email === listing.owner_email) return;
        const thread = await getOrCreateListingThread(listing, user);
        setSelectedThread(thread);
        setShowChat(true);
      }).catch(() => {});
    }
  }, [user, threads.length]);

  const handleSelect = (thread) => {
    setSelectedThread(thread);
    setShowChat(true);
  };

  const handleBack = () => {
    setShowChat(false);
    setSelectedThread(null);
    refetchThreads();
  };

  if (!user) return null;

  return (
    <div className="flex" style={{ height: 'calc(100dvh - 68px)' }}>
      {/* Sidebar — left */}
      <div className={`${showChat ? 'hidden md:flex' : 'flex'} w-full md:w-[360px] lg:w-[380px] shrink-0 border-r border-border/40`}>
        <ChatSidebar
          threads={threads}
          user={user}
          selectedId={selectedThread?.id}
          onSelect={handleSelect}
        />
      </div>

      {/* Conversation — right */}
      <div className={`${!showChat ? 'hidden md:flex' : 'flex'} flex-1 min-w-0`}>
        {selectedThread ? (
          <ChatConversation
            thread={selectedThread}
            user={user}
            booking={activeBooking}
            onBack={handleBack}
          />
        ) : (
          <ChatEmptyState />
        )}
      </div>
    </div>
  );
}