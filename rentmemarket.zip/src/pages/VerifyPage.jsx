import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { ChevronLeft, Upload, CheckCircle2, Loader2, X } from 'lucide-react';
import { isMobileDevice } from '@/components/common/QRPhotoUpload';
import QRPhotoUpload from '@/components/common/QRPhotoUpload';

const STEPS = [
  { num: 1, label: 'Документ за самоличност' },
  { num: 2, label: 'Селфи с документ' },
  { num: 3, label: 'Потвърждение' },
];

export default function VerifyPage() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [step, setStep] = useState(1);
  const [idFront, setIdFront] = useState(null);
  const [idBack, setIdBack] = useState(null);
  const [selfie, setSelfie] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [existingKyc, setExistingKyc] = useState(null);

  useEffect(() => {
    base44.auth.me().then(async u => {
      setUser(u);
      const kycs = await base44.entities.KYCVerification.filter({ user_email: u.email });
      if (kycs[0]) setExistingKyc(kycs[0]);
    }).catch(() => navigate('/'));
  }, []);

  const uploadPhoto = async (file, setter) => {
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) { toast.error('Файлът е твърде голям (макс. 5MB)'); return; }
    setUploading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setter(file_url);
    setUploading(false);
  };

  const handleSubmit = async () => {
    if (!idFront || !selfie) { toast.error('Моля качи задължителните снимки'); return; }
    setSubmitting(true);
    await base44.entities.KYCVerification.create({
      user_email: user.email,
      user_name: user.full_name,
      id_photo_front: idFront,
      id_photo_back: idBack || '',
      selfie_photo: selfie,
      status: 'pending',
    });
    setStep(3);
    setSubmitting(false);
  };

  if (!user) return <div className="flex items-center justify-center min-h-[50vh]"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>;

  if (existingKyc) {
    const statusInfo = {
      pending: { label: 'В процес на проверка', color: 'text-yellow-700 bg-yellow-50 border-yellow-200', icon: '⏳' },
      approved: { label: 'Верифициран', color: 'text-green-700 bg-green-50 border-green-200', icon: '✅' },
      rejected: { label: 'Отхвърлено', color: 'text-red-700 bg-red-50 border-red-200', icon: '❌' },
    }[existingKyc.status];
    return (
      <div className="max-w-md mx-auto px-4 py-10 text-center">
        <Link to="/settings" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-8">
          <ChevronLeft className="w-4 h-4" /> Обратно към настройки
        </Link>
        <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-xl border text-sm font-semibold mb-4 ${statusInfo.color}`}>
          {statusInfo.icon} {statusInfo.label}
        </div>
        <h2 className="font-heading text-xl font-bold mb-2">Верификация на самоличност</h2>
        {existingKyc.status === 'pending' && <p className="text-muted-foreground text-sm">Документите ти са изпратени и се проверяват от нашия екип. Ще получиш известие след приключване на проверката.</p>}
        {existingKyc.status === 'approved' && <p className="text-muted-foreground text-sm">Самоличността ти е потвърдена. Можеш да публикуваш обяви и да наемаш артикули.</p>}
        {existingKyc.status === 'rejected' && (
          <>
            <p className="text-muted-foreground text-sm mb-4">Заявката ти беше отхвърлена. {existingKyc.notes && <span>Причина: {existingKyc.notes}</span>}</p>
            <Button onClick={() => setExistingKyc(null)} className="gradient-bg text-white border-0">Опитай отново</Button>
          </>
        )}
      </div>
    );
  }

  if (step === 3) {
    return (
      <div className="max-w-md mx-auto px-4 py-10 text-center">
        <CheckCircle2 className="w-16 h-16 text-green-500 mx-auto mb-4" />
        <h2 className="font-heading text-2xl font-bold mb-2">Данните са изпратени!</h2>
        <p className="text-muted-foreground text-sm mb-6">Статусът ти е сменен на „В процес". Ще получиш известие след приключване на проверката.</p>
        <Button onClick={() => navigate('/settings')} className="gradient-bg text-white border-0">Обратно към настройки</Button>
      </div>
    );
  }

  return (
    <div className="max-w-md mx-auto px-4 py-8">
      <Link to="/settings" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-6">
        <ChevronLeft className="w-4 h-4" /> Обратно
      </Link>

      <h1 className="font-heading text-2xl font-bold mb-1">Верификация на самоличност</h1>
      <p className="text-muted-foreground text-sm mb-6">Потвърди самоличността си, за да публикуваш обяви и наемаш артикули.</p>

      {/* Progress */}
      <div className="flex items-center gap-2 mb-8">
        {STEPS.map((s, i) => (
          <React.Fragment key={s.num}>
            <div className="flex flex-col items-center">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${s.num <= step ? 'gradient-bg text-white' : 'bg-muted text-muted-foreground'}`}>
                {s.num < step ? <CheckCircle2 className="w-4 h-4" /> : s.num}
              </div>
              <span className={`text-[10px] mt-1 text-center leading-tight ${s.num <= step ? 'text-foreground font-medium' : 'text-muted-foreground'}`}>{s.label}</span>
            </div>
            {i < STEPS.length - 1 && <div className={`flex-1 h-0.5 mb-4 ${s.num < step ? 'gradient-bg' : 'bg-muted'}`} />}
          </React.Fragment>
        ))}
      </div>

      {/* Step 1 */}
      {step === 1 && (
        <div className="space-y-4">
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 text-sm text-blue-700">
            💡 Качи снимка на лична карта или паспорт
          </div>
          <PhotoUploadSlot label="Предна страна *" value={idFront} onUpload={f => uploadPhoto(f, setIdFront)} onRemove={() => setIdFront(null)} uploading={uploading} />
          <PhotoUploadSlot label="Задна страна (по избор)" value={idBack} onUpload={f => uploadPhoto(f, setIdBack)} onRemove={() => setIdBack(null)} uploading={uploading} />
          <Button onClick={() => { if (!idFront) { toast.error('Предната страна е задължителна'); return; } setStep(2); }} className="w-full gradient-bg text-white border-0" disabled={uploading}>
            Продължи →
          </Button>
        </div>
      )}

      {/* Step 2 */}
      {step === 2 && (
        <div className="space-y-4">
          <div className="bg-purple-50 border border-purple-200 rounded-xl p-3 text-sm text-purple-700">
            🤳 Качи снимка на теб, държащ документа
          </div>
          <PhotoUploadSlot label="Селфи с документ *" value={selfie} onUpload={f => uploadPhoto(f, setSelfie)} onRemove={() => setSelfie(null)} uploading={uploading} />
          <div className="flex gap-3">
            <Button variant="outline" onClick={() => setStep(1)} className="flex-1">← Назад</Button>
            <Button
              onClick={handleSubmit}
              className="flex-1 gradient-bg text-white border-0"
              disabled={!selfie || submitting || uploading}
            >
              {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Изпрати →'}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}

function PhotoUploadSlot({ label, value, onUpload, onRemove, uploading }) {
  const isMobile = isMobileDevice();
  return (
    <div>
      <p className="text-sm font-medium text-foreground mb-2">{label}</p>
      {value ? (
        <div className="relative rounded-xl overflow-hidden border border-border">
          <img src={value} alt="" className="w-full h-48 object-cover" />
          <button onClick={onRemove} className="absolute top-2 right-2 w-7 h-7 bg-black/60 rounded-full flex items-center justify-center text-white hover:bg-black/80">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      ) : isMobile ? (
        <label className={`flex flex-col items-center justify-center h-40 rounded-xl border-2 border-dashed border-border bg-muted/30 cursor-pointer hover:bg-muted/50 transition-colors ${uploading ? 'opacity-50 pointer-events-none' : ''}`}>
          <Upload className="w-8 h-8 text-muted-foreground mb-2" />
          <span className="text-sm text-muted-foreground">{uploading ? 'Качване...' : 'Кликни за снимка'}</span>
          <input type="file" accept="image/*" capture="environment" className="hidden" onChange={e => e.target.files[0] && onUpload(e.target.files[0])} />
        </label>
      ) : (
        <QRPhotoUpload onRefresh={() => window.location.reload()} />
      )}
    </div>
  );
}