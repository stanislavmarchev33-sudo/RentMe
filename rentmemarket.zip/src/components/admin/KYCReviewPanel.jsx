import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { Check, X, Loader2, ExternalLink } from 'lucide-react';

const statusColors = {
  pending: 'bg-yellow-100 text-yellow-700',
  approved: 'bg-green-100 text-green-700',
  rejected: 'bg-red-100 text-red-700',
};
const statusLabels = { pending: 'В процес', approved: 'Одобрен', rejected: 'Отхвърлен' };

export default function KYCReviewPanel() {
  const queryClient = useQueryClient();
  const [notes, setNotes] = useState({});
  const [expanded, setExpanded] = useState(null);

  const { data: kycs = [], isLoading } = useQuery({
    queryKey: ['admin-kyc'],
    queryFn: () => base44.entities.KYCVerification.list('-created_date', 100),
    initialData: [],
  });

  const reviewMutation = useMutation({
    mutationFn: async ({ id, status, note }) => {
      await base44.entities.KYCVerification.update(id, {
        status,
        notes: note || '',
        reviewed_at: new Date().toISOString(),
      });
      // Also update user's is_verified if approved
      if (status === 'approved') {
        const kyc = kycs.find(k => k.id === id);
        if (kyc) {
          const users = await base44.entities.User.filter({ email: kyc.user_email });
          if (users[0]) await base44.entities.User.update(users[0].id, { is_verified: true });
          // Notify user
          await base44.entities.Notification.create({
            user_email: kyc.user_email,
            type: 'verification',
            title: 'Самоличността ти е потвърдена! ✅',
            message: 'Вече можеш да публикуваш обяви и да наемаш артикули.',
            link: '/settings',
          });
        }
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-kyc'] });
      toast.success('Обновено!');
    },
  });

  const pending = kycs.filter(k => k.status === 'pending');
  const reviewed = kycs.filter(k => k.status !== 'pending');

  if (isLoading) return <div className="flex items-center justify-center py-8"><Loader2 className="w-5 h-5 animate-spin text-primary" /></div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <h3 className="font-semibold text-lg">KYC Верификации</h3>
        {pending.length > 0 && (
          <Badge className="bg-yellow-100 text-yellow-700">{pending.length} чакащи</Badge>
        )}
      </div>

      {pending.length === 0 && (
        <p className="text-muted-foreground text-sm py-4 text-center">Няма чакащи верификации</p>
      )}

      {/* Pending first */}
      {[...pending, ...reviewed].map(kyc => (
        <Card key={kyc.id} className={kyc.status === 'pending' ? 'border-yellow-200' : ''}>
          <CardContent className="p-4">
            <div className="flex items-start justify-between gap-3 mb-3">
              <div>
                <p className="font-semibold">{kyc.user_name || kyc.user_email}</p>
                <p className="text-xs text-muted-foreground">{kyc.user_email} · {kyc.created_date?.slice(0, 10)}</p>
              </div>
              <div className="flex items-center gap-2">
                <Badge className={statusColors[kyc.status]}>{statusLabels[kyc.status]}</Badge>
                <button
                  onClick={() => setExpanded(expanded === kyc.id ? null : kyc.id)}
                  className="text-xs text-primary underline"
                >
                  {expanded === kyc.id ? 'Скрий' : 'Виж снимки'}
                </button>
              </div>
            </div>

            {expanded === kyc.id && (
              <div className="grid grid-cols-3 gap-3 mb-4">
                {[
                  { url: kyc.id_photo_front, label: 'ЛК Предна' },
                  { url: kyc.id_photo_back, label: 'ЛК Задна' },
                  { url: kyc.selfie_photo, label: 'Селфи' },
                ].filter(p => p.url).map(p => (
                  <div key={p.label}>
                    <p className="text-xs text-muted-foreground mb-1">{p.label}</p>
                    <a href={p.url} target="_blank" rel="noopener noreferrer" className="block relative group">
                      <img src={p.url} alt={p.label} className="w-full h-32 object-cover rounded-lg border" />
                      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors rounded-lg flex items-center justify-center">
                        <ExternalLink className="w-4 h-4 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                      </div>
                    </a>
                  </div>
                ))}
              </div>
            )}

            {kyc.status === 'pending' && (
              <div className="space-y-2">
                <Textarea
                  placeholder="Бележка (по избор при отхвърляне)"
                  value={notes[kyc.id] || ''}
                  onChange={e => setNotes(n => ({ ...n, [kyc.id]: e.target.value }))}
                  rows={2}
                  className="text-sm"
                />
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    className="flex-1 gap-1 bg-green-600 hover:bg-green-700 text-white border-0"
                    onClick={() => reviewMutation.mutate({ id: kyc.id, status: 'approved', note: notes[kyc.id] })}
                    disabled={reviewMutation.isPending}
                  >
                    <Check className="w-3.5 h-3.5" /> Одобри
                  </Button>
                  <Button
                    size="sm"
                    variant="destructive"
                    className="flex-1 gap-1"
                    onClick={() => reviewMutation.mutate({ id: kyc.id, status: 'rejected', note: notes[kyc.id] })}
                    disabled={reviewMutation.isPending}
                  >
                    <X className="w-3.5 h-3.5" /> Откажи
                  </Button>
                </div>
              </div>
            )}

            {kyc.status !== 'pending' && kyc.notes && (
              <p className="text-xs text-muted-foreground mt-2">Бележка: {kyc.notes}</p>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}