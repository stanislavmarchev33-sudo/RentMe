import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { toast } from 'sonner';
import { Loader2, Check, X, Ban } from 'lucide-react';

const reasonLabels = {
  spam: 'Спам / Фалшива обява',
  inappropriate: 'Неприлично съдържание',
  fraud: 'Измама',
  wrong_info: 'Грешна информация',
  other: 'Друго',
};

const typeLabels = { review: 'Рецензия', listing: 'Обява', user: 'Потребител' };
const statusColors = { pending: 'bg-yellow-100 text-yellow-700', resolved: 'bg-green-100 text-green-700', dismissed: 'bg-gray-100 text-gray-500' };

export default function ReportsPanel() {
  const queryClient = useQueryClient();
  const [filter, setFilter] = useState('pending');

  const { data: reports = [], isLoading } = useQuery({
    queryKey: ['admin-reports'],
    queryFn: () => base44.entities.Report.list('-created_date', 200),
    initialData: [],
  });

  const actionMutation = useMutation({
    mutationFn: async ({ report, action }) => {
      const adminUser = await base44.auth.me();
      await base44.entities.Report.update(report.id, {
        status: action === 'dismiss' ? 'dismissed' : 'resolved',
        resolved_by: adminUser?.email,
        resolved_at: new Date().toISOString(),
        action_taken: action,
      });

      if (action === 'remove_content' && report.reported_type === 'listing') {
        await base44.entities.Listing.update(report.reported_id, { status: 'suspended' });
        // Notify owner
        const listings = await base44.entities.Listing.filter({ id: report.reported_id });
        if (listings[0]) {
          await base44.entities.Notification.create({
            user_email: listings[0].owner_email,
            type: 'system',
            title: 'Обявата ти беше премахната',
            message: 'Обявата ти беше премахната поради нарушение на правилата на платформата.',
            link: '/dashboard',
          });
          base44.functions.invoke('sendBookingEmail', {
            templateKey: 'listing_removed',
            to: listings[0].owner_email,
            params: { listingTitle: listings[0].title },
          }).catch(() => {});
        }
      }

      if (action === 'remove_content' && report.reported_type === 'review') {
        await base44.entities.Review.delete(report.reported_id);
      }

      if (action === 'suspend_user') {
        const users = await base44.entities.User.filter({ email: report.reported_id });
        if (users[0]) {
          await base44.entities.User.update(users[0].id, {
            is_suspended: true,
            suspension_reason: `Докладван: ${reasonLabels[report.reason]}`,
          });
        }
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-reports'] });
      toast.success('Действието е изпълнено!');
    },
  });

  const shown = reports.filter(r => filter === 'all' || r.status === filter);

  if (isLoading) return <div className="flex items-center justify-center py-8"><Loader2 className="w-5 h-5 animate-spin text-primary" /></div>;

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <h3 className="font-semibold text-lg">Доклади</h3>
        <Badge className="bg-yellow-100 text-yellow-700">{reports.filter(r => r.status === 'pending').length} чакащи</Badge>
      </div>

      <div className="flex gap-2">
        {['pending', 'resolved', 'dismissed', 'all'].map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${filter === f ? 'gradient-bg text-white' : 'bg-muted text-muted-foreground hover:bg-muted/80'}`}
          >
            {{ pending: 'Чакащи', resolved: 'Решени', dismissed: 'Отхвърлени', all: 'Всички' }[f]}
          </button>
        ))}
      </div>

      {shown.length === 0 && <p className="text-muted-foreground text-sm py-4 text-center">Няма доклади</p>}

      {shown.map(report => (
        <Card key={report.id} className={report.status === 'pending' ? 'border-yellow-200' : ''}>
          <CardContent className="p-4">
            <div className="flex items-start justify-between gap-3 mb-2">
              <div>
                <div className="flex items-center gap-2 flex-wrap mb-1">
                  <Badge variant="outline" className="text-xs">{typeLabels[report.reported_type] || report.reported_type}</Badge>
                  <Badge className={statusColors[report.status] || 'bg-gray-100 text-gray-500'}>{report.status}</Badge>
                  <span className="text-xs text-muted-foreground">{report.created_date?.slice(0, 10)}</span>
                </div>
                <p className="text-sm font-medium">{reasonLabels[report.reason] || report.reason}</p>
                {report.reported_label && <p className="text-xs text-muted-foreground truncate max-w-xs">«{report.reported_label}»</p>}
                {report.details && <p className="text-xs text-muted-foreground mt-1 italic">"{report.details}"</p>}
                <p className="text-xs text-muted-foreground mt-1">Докладвано от: {report.reporter_name || report.reporter_email}</p>
              </div>
            </div>

            {report.status === 'pending' && (
              <div className="flex gap-2 mt-3 flex-wrap">
                <Button size="sm" variant="outline" className="gap-1 text-xs"
                  onClick={() => actionMutation.mutate({ report, action: 'dismiss' })}
                  disabled={actionMutation.isPending}
                >
                  <Check className="w-3 h-3" /> Отхвърли
                </Button>
                <Button size="sm" variant="destructive" className="gap-1 text-xs"
                  onClick={() => actionMutation.mutate({ report, action: 'remove_content' })}
                  disabled={actionMutation.isPending}
                >
                  <X className="w-3 h-3" /> Премахни съдържание
                </Button>
                {report.reported_type === 'user' && (
                  <Button size="sm" className="gap-1 text-xs bg-red-700 hover:bg-red-800 text-white border-0"
                    onClick={() => actionMutation.mutate({ report, action: 'suspend_user' })}
                    disabled={actionMutation.isPending}
                  >
                    <Ban className="w-3 h-3" /> Спри потребителя
                  </Button>
                )}
              </div>
            )}
            {report.action_taken && (
              <p className="text-xs text-muted-foreground mt-2">Действие: {report.action_taken} — от {report.resolved_by}</p>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}