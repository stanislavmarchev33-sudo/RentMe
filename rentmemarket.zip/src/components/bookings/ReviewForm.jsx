import React, { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { toast } from 'sonner';
import { Star, Send, Loader2 } from 'lucide-react';

export default function ReviewForm({ booking, reviewerEmail, reviewerName, isOwner, onSuccess }) {
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [comment, setComment] = useState('');

  const mutation = useMutation({
    mutationFn: async () => {
      const reviewer = reviewerEmail || booking.renter_email;
      const reviewerN = reviewerName || booking.renter_name;
      const reviewee = isOwner ? booking.renter_email : booking.owner_email;
      const type = isOwner ? 'owner_to_renter' : 'renter_to_owner';

      await base44.entities.Review.create({
        booking_id: booking.id,
        listing_id: booking.listing_id,
        reviewer_email: reviewer,
        reviewer_name: reviewerN,
        reviewee_email: reviewee,
        type,
        rating,
        comment: comment.trim(),
      });
    },
    onSuccess: () => {
      toast.success('Рецензията беше изпратена!');
      onSuccess?.();
    },
  });

  const handleSubmit = () => {
    if (rating === 0) { toast.error('Моля изберете оценка'); return; }
    mutation.mutate();
  };

  return (
    <Card>
      <CardContent className="p-5">
        <h3 className="font-heading font-semibold text-gray-900 mb-4">
          {isOwner ? 'Оцени наемателя' : 'Оцени наема'}
        </h3>

        <div className="flex gap-2 mb-4">
          {[1, 2, 3, 4, 5].map(star => (
            <button
              key={star}
              onMouseEnter={() => setHoverRating(star)}
              onMouseLeave={() => setHoverRating(0)}
              onClick={() => setRating(star)}
              className="transition-transform hover:scale-110"
            >
              <Star className={`w-8 h-8 ${star <= (hoverRating || rating) ? 'fill-yellow-400 text-yellow-400' : 'text-gray-200'}`} />
            </button>
          ))}
        </div>

        <Textarea
          value={comment}
          onChange={e => setComment(e.target.value)}
          placeholder={isOwner ? 'Как беше наемателят? (по избор)' : 'Какво мислиш за артикула и собственика? (по избор)'}
          rows={3}
          className="mb-4"
        />

        <Button
          onClick={handleSubmit}
          disabled={mutation.isPending}
          className="w-full gradient-bg text-white border-0 h-11 rounded-xl font-semibold flex items-center justify-center gap-2"
        >
          {mutation.isPending && <Loader2 className="w-4 h-4 animate-spin" />}
          <Send className="w-4 h-4" />
          Изпрати рецензия
        </Button>
      </CardContent>
    </Card>
  );
}