import React, { useState, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { AlertTriangle, Upload, X, Loader2, ImagePlus } from 'lucide-react';
import { toast } from 'sonner';
import { isMobileDevice } from '@/components/common/QRPhotoUpload';
import QRPhotoUpload from '@/components/common/QRPhotoUpload';

export default function PhotoUploadModal({ open, onClose, onConfirm, onRefresh, title, warning, confirmLabel = 'Потвърди', minPhotos = 1, maxPhotos = 5 }) {
  const [photos, setPhotos] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [confirming, setConfirming] = useState(false);
  const fileInputRef = useRef();
  const isMobile = isMobileDevice();

  const handleFiles = async (files) => {
    const remaining = maxPhotos - photos.length;
    const toUpload = Array.from(files).slice(0, remaining);
    if (!toUpload.length) return;

    setUploading(true);
    const uploaded = [];
    for (const file of toUpload) {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      uploaded.push(file_url);
    }
    setPhotos(prev => [...prev, ...uploaded]);
    setUploading(false);
  };

  const removePhoto = (idx) => setPhotos(prev => prev.filter((_, i) => i !== idx));

  const handleConfirm = async () => {
    if (photos.length < minPhotos) {
      toast.error(`Качи поне ${minPhotos} снимка.`);
      return;
    }
    setConfirming(true);
    await onConfirm(photos);
    setConfirming(false);
    setPhotos([]);
    onClose();
  };

  const handleClose = () => {
    if (confirming || uploading) return;
    setPhotos([]);
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="text-base font-semibold">{title}</DialogTitle>
        </DialogHeader>

        {/* Desktop: show QR code */}
        {!isMobile ? (
          <QRPhotoUpload onRefresh={onRefresh} />
        ) : (
          <>
            {warning && (
              <div className="flex items-start gap-2 p-3 rounded-xl bg-amber-50 border border-amber-200 text-sm text-amber-700">
                <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
                {warning}
              </div>
            )}

            {/* Photo grid */}
            <div className="grid grid-cols-3 gap-2 mt-1">
              {photos.map((url, i) => (
                <div key={i} className="relative aspect-square rounded-xl overflow-hidden border border-gray-200">
                  <img src={url} alt="" className="w-full h-full object-cover" />
                  <button
                    onClick={() => removePhoto(i)}
                    className="absolute top-1 right-1 w-5 h-5 rounded-full bg-black/60 flex items-center justify-center text-white hover:bg-black/80"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ))}
              {photos.length < maxPhotos && (
                <button
                  onClick={() => fileInputRef.current?.click()}
                  disabled={uploading}
                  className="aspect-square rounded-xl border-2 border-dashed border-gray-300 flex flex-col items-center justify-center text-gray-400 hover:border-primary/50 hover:text-primary transition-colors"
                >
                  {uploading ? <Loader2 className="w-5 h-5 animate-spin" /> : <ImagePlus className="w-5 h-5" />}
                  <span className="text-xs mt-1">{uploading ? 'Качва...' : 'Добави'}</span>
                </button>
              )}
            </div>

            <p className="text-xs text-muted-foreground">
              {photos.length}/{maxPhotos} снимки • мин. {minPhotos} задължителна
            </p>

            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              capture="environment"
              multiple
              className="hidden"
              onChange={e => handleFiles(e.target.files)}
            />

            <div className="flex gap-2 mt-2">
              <Button variant="outline" onClick={handleClose} disabled={confirming || uploading} className="flex-1">
                Отказ
              </Button>
              <Button
                onClick={handleConfirm}
                disabled={photos.length < minPhotos || confirming || uploading}
                className="flex-1 gradient-bg text-white border-0 gap-2"
              >
                {confirming ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
                {confirmLabel}
              </Button>
            </div>
          </>
        )}

        {/* Desktop close button */}
        {!isMobile && (
          <Button variant="outline" onClick={handleClose} className="w-full mt-2">
            Затвори
          </Button>
        )}
      </DialogContent>
    </Dialog>
  );
}