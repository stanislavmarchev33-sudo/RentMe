import React, { useState } from 'react';
import { Star, Flag } from 'lucide-react';
import ReportModal from '@/components/common/ReportModal';

function StarBar({ count, total, star }) {
  const pct = total > 0 ? Math.round((count / total) * 100) : 0;
  return (
    <div className="flex items-center gap-2">
      <span className="text-xs text-gray-500 w-3">{star}</span>
      <Star className="w-3 h-3 fill-yellow-400 text-yellow-400 shrink-0" />
      <div className="flex-1 h-1.5 bg-gray-100 rounded-full overflow-hidden">
        <div className="h-full bg-yellow-400 rounded-full" style={{ width: `${pct}%` }} />
      </div>
      <span className="text-xs text-gray-400 w-5 text-right">{count}</span>
    </div>
  );
}

function ReviewCard({ review, onReport }) {
  const initials = review.reviewer_name?.split(' ').map(p => p[0]).join('').toUpperCase().slice(0, 2) || '?';
  return (
    <div className="p-4 bg-muted/40 rounded-xl relative">
      <div className="flex items-start gap-3 mb-2">
        <div className="w-9 h-9 rounded-full gradient-bg flex items-center justify-center text-white text-sm font-bold shrink-0">
          {initials}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-sm font-semibold text-foreground">{review.reviewer_name}</span>
            <span className="text-xs text-muted-foreground">{review.created_date?.slice(0, 10)}</span>
          </div>
          <div className="flex gap-0.5 mt-0.5">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star key={i} className={`w-3.5 h-3.5 ${i < review.rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-200'}`} />
            ))}
          </div>
        </div>
      </div>
      {review.comment && <p className="text-sm text-muted-foreground leading-relaxed ml-12">{review.comment}</p>}
      <button
        onClick={() => onReport(review)}
        className="absolute bottom-3 right-3 flex items-center gap-1 text-[10px] text-gray-400 hover:text-red-400 transition-colors"
      >
        <Flag className="w-3 h-3" /> Докладвай
      </button>
    </div>
  );
}

export default function ReviewsSection({ reviews, listingId }) {
  const [showAll, setShowAll] = useState(false);
  const [reportTarget, setReportTarget] = useState(null);

  if (!reviews || reviews.length === 0) return null;

  const total = reviews.length;
  const avg = (reviews.reduce((s, r) => s + r.rating, 0) / total).toFixed(1);
  const counts = [5, 4, 3, 2, 1].map(s => ({ star: s, count: reviews.filter(r => r.rating === s).length }));
  const shown = showAll ? reviews : reviews.slice(0, 5);

  return (
    <div className="mt-8">
      {/* Header + aggregate */}
      <h3 className="font-heading font-semibold text-lg mb-4">Рецензии ({total})</h3>
      <div className="flex gap-6 mb-6 p-4 bg-muted/30 rounded-xl">
        <div className="text-center shrink-0">
          <div className="text-4xl font-heading font-bold gradient-text">{avg}</div>
          <div className="flex justify-center gap-0.5 my-1">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star key={i} className={`w-4 h-4 ${i < Math.round(parseFloat(avg)) ? 'fill-yellow-400 text-yellow-400' : 'text-gray-200'}`} />
            ))}
          </div>
          <p className="text-xs text-muted-foreground">{total} рецензии</p>
        </div>
        <div className="flex-1 space-y-1.5">
          {counts.map(({ star, count }) => (
            <StarBar key={star} star={star} count={count} total={total} />
          ))}
        </div>
      </div>

      {/* Review list */}
      <div className="space-y-3">
        {shown.map(r => (
          <ReviewCard key={r.id} review={r} onReport={r => setReportTarget({ type: 'review', id: r.id, label: `Рецензия от ${r.reviewer_name}` })} />
        ))}
      </div>

      {!showAll && reviews.length > 5 && (
        <button onClick={() => setShowAll(true)} className="mt-4 text-sm text-primary font-semibold hover:underline">
          Виж всички {reviews.length} рецензии →
        </button>
      )}

      {reportTarget && (
        <ReportModal
          type={reportTarget.type}
          reportedId={reportTarget.id}
          reportedLabel={reportTarget.label}
          onClose={() => setReportTarget(null)}
        />
      )}
    </div>
  );
}