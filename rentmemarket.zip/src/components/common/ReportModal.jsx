import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { Flag, X, Loader2 } from 'lucide-react';

const REASONS = [
  { value: 'spam', label: 'Спам / Фалшива обява' },
  { value: 'inappropriate', label: 'Неприлично съдържание' },
  { value: 'fraud', label: 'Измама или измамно поведение' },
  { value: 'wrong_info', label: 'Грешна информация' },
  { value: 'other', label: 'Друго' },
];

export default function ReportModal({ type, reportedId, reportedLabel, onClose }) {
  const [reason, setReason] = useState('');
  const [details, setDetails] = useState('');
  const [loading, setLoading] = useState(false);
  const [user, setUser] = useState(null);

  useEffect(() => { base44.auth.me().then(setUser).catch(() => {}); }, []);

  const handleSubmit = async () => {
    if (!reason) { toast.error('Избери причина'); return; }
    setLoading(true);
    await base44.entities.Report.create({
      reporter_email: user?.email || 'anonymous',
      reporter_name: user?.full_name || '',
      reported_type: type,
      reported_id: reportedId,
      reported_label: reportedLabel || '',
      reason,
      details,
      status: 'pending',
    });
    toast.success('Докладът е изпратен. Благодарим!');
    setLoading(false);
    onClose();
  };

  const typeLabels = { review: 'рецензия', listing: 'обява', user: 'потребител' };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" onClick={onClose}>
      <div className="bg-card rounded-2xl shadow-xl w-full max-w-sm p-5" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Flag className="w-4 h-4 text-red-500" />
            <h3 className="font-semibold">Докладвай {typeLabels[type] || type}</h3>
          </div>
          <button onClick={onClose}><X className="w-4 h-4 text-muted-foreground" /></button>
        </div>

        {reportedLabel && <p className="text-xs text-muted-foreground mb-3 truncate">«{reportedLabel}»</p>}

        <div className="space-y-2 mb-3">
          {REASONS.map(r => (
            <button
              key={r.value}
              onClick={() => setReason(r.value)}
              className={`w-full text-left text-sm px-3 py-2 rounded-lg border transition-colors ${
                reason === r.value ? 'border-primary bg-primary/5 text-primary font-medium' : 'border-border hover:bg-muted/50'
              }`}
            >
              {r.label}
            </button>
          ))}
        </div>

        {reason === 'other' && (
          <Textarea
            value={details}
            onChange={e => setDetails(e.target.value)}
            placeholder="Опиши проблема..."
            rows={3}
            className="mb-3 text-sm"
          />
        )}

        <div className="flex gap-2">
          <Button variant="outline" onClick={onClose} className="flex-1" size="sm">Откажи</Button>
          <Button onClick={handleSubmit} disabled={loading || !reason} className="flex-1 bg-red-500 hover:bg-red-600 text-white border-0" size="sm">
            {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : 'Изпрати'}
          </Button>
        </div>
      </div>
    </div>
  );
}