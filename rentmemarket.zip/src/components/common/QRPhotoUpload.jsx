import React from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { Smartphone } from 'lucide-react';

// Detects if current device is mobile
export function isMobileDevice() {
  return /Android|iPhone|iPad|iPod|Opera Mini|IEMobile|WPDesktop/i.test(navigator.userAgent);
}

/**
 * Desktop QR mode — shows QR code and polls for booking updates.
 * onRefresh: callback called every 10s so parent can re-fetch data.
 */
export default function QRPhotoUpload({ onRefresh }) {
  const url = window.location.href;

  return (
    <div className="flex flex-col items-center gap-5 py-4">
      <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center">
        <Smartphone className="w-6 h-6 text-primary" />
      </div>

      <div>
        <h3 className="font-heading font-semibold text-center text-base">Сканирай с телефона си за да продължиш</h3>
        <p className="text-sm text-muted-foreground text-center mt-1">Снимките трябва да са заснети в момента на телефон</p>
      </div>

      <div className="p-4 bg-white rounded-2xl border border-border shadow-sm">
        <QRCodeSVG value={url} size={180} fgColor="#1e2a6e" />
      </div>

      <div className="text-center">
        <p className="text-xs text-muted-foreground">
          След като заснемеш снимките на телефона, страницата тук ще се обнови автоматично
        </p>
      </div>
    </div>
  );
}