import React, { useState } from 'react';
import { Search, MessageSquare } from 'lucide-react';
import ChatAvatar from './ChatAvatar';
import { fmtMsgTime } from '@/lib/chatUtils';

export default function ChatSidebar({ threads, user, selectedId, onSelect }) {
  const [search, setSearch] = useState('');

  const filtered = threads.filter((t) => {
    if (!search) return true;
    const emails = t.participant_emails || [];
    const names = t.participant_names || [];
    const idx = emails.findIndex((e) => e !== user?.email);
    const other = (names[idx] || emails[idx] || '').toLowerCase();
    return (
      other.includes(search.toLowerCase()) ||
      (t.listing_title || '').toLowerCase().includes(search.toLowerCase())
    );
  });

  return (
    <div className="flex flex-col h-full bg-card">
      {/* Header */}
      <div className="px-4 pt-4 pb-2 shrink-0">
        <h1 className="font-heading text-xl font-bold mb-3">Съобщения</h1>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            placeholder="Търси разговор..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2.5 bg-muted/50 rounded-full text-sm outline-none placeholder:text-muted-foreground border border-transparent focus:border-primary/30 transition-colors"
          />
        </div>
      </div>

      {/* List */}
      <div className="flex-1 overflow-y-auto">
        {filtered.length === 0 ? (
          <div className="text-center py-20 px-4">
            <div className="w-14 h-14 rounded-full bg-muted/60 flex items-center justify-center mx-auto mb-3">
              <MessageSquare className="w-6 h-6 text-muted-foreground/40" />
            </div>
            <p className="text-sm font-medium text-muted-foreground">Нямаш съобщения още</p>
            <p className="text-xs text-muted-foreground/60 mt-1">Разговорите се появяват след заявка за наем</p>
          </div>
        ) : (
          filtered.map((thread) => {
            const emails = thread.participant_emails || [];
            const names = thread.participant_names || [];
            const idx = emails.findIndex((e) => e !== user?.email);
            const otherName = names[idx] || emails[idx] || 'Потребител';
            const unread = thread.unread_count || 0;
            const active = selectedId === thread.id;

            return (
              <button
                key={thread.id}
                onClick={() => onSelect(thread)}
                className={`w-full text-left flex items-center gap-3 px-3 py-3 transition-colors ${
                  active ? 'bg-primary/10' : 'hover:bg-muted/40'
                }`}
              >
                <ChatAvatar name={otherName} size={48} />
                <div className="flex-1 min-w-0 text-left">
                  <div className="flex items-center justify-between mb-0.5">
                    <span className={`text-[15px] truncate ${unread > 0 ? 'font-bold text-foreground' : 'font-semibold text-foreground/85'}`}>
                      {otherName}
                    </span>
                    <span className={`text-[11px] ml-2 shrink-0 ${unread > 0 ? 'text-primary font-semibold' : 'text-muted-foreground'}`}>
                      {fmtMsgTime(thread.last_message_at || thread.updated_date)}
                    </span>
                  </div>
                  {thread.listing_title && (
                    <p className="text-[11px] text-primary font-medium truncate mb-0.5">{thread.listing_title}</p>
                  )}
                  <div className="flex items-center gap-2">
                    <p className={`text-[13px] truncate flex-1 ${unread > 0 ? 'font-medium text-foreground' : 'text-muted-foreground'}`}>
                      {thread.last_message || 'Няма съобщения'}
                    </p>
                    {unread > 0 && (
                      <span className="shrink-0 min-w-[20px] h-5 rounded-full gradient-bg text-white text-[11px] flex items-center justify-center font-bold px-1.5">
                        {unread > 9 ? '9+' : unread}
                      </span>
                    )}
                  </div>
                </div>
              </button>
            );
          })
        )}
      </div>
    </div>
  );
}