import React from 'react';
import { getInitials } from '@/lib/chatUtils';

export default function ChatAvatar({ name, size = 48, ring = false }) {
  const px = `${size}px`;
  return (
    <div
      className={`rounded-full gradient-bg flex items-center justify-center shrink-0 text-white font-semibold ${ring ? 'ring-2 ring-white shadow-sm' : ''}`}
      style={{ width: px, height: px, fontSize: size * 0.36 }}
    >
      {getInitials(name)}
    </div>
  );
}