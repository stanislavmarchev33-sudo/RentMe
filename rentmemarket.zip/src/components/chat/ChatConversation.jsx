import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Send, Lock, Loader2, MessageSquare } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import ChatAvatar from './ChatAvatar';
import { redactContent, fmtMsgTime, fmtDateDivider, groupByDate } from '@/lib/chatUtils';

const PAID_STATUSES = ['paid', 'active', 'item_sent', 'item_received', 'returning', 'returned', 'completed'];

export default function ChatConversation({ thread, user, booking, onBack }) {
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const bottomRef = useRef();
  const inputRef = useRef();

  const isPaid = PAID_STATUSES.includes(booking?.status);

  const emails = thread.participant_emails || [];
  const names = thread.participant_names || [];
  const idx = emails.findIndex((e) => e !== user?.email);
  const otherName = names[idx] || emails[idx] || 'Потребител';
  const otherEmail = emails[idx];

  // Load messages + reset unread
  useEffect(() => {
    if (!thread?.id) return;
    let cancelled = false;
    (async () => {
      const msgs = await base44.entities.ChatMessage.filter({ thread_id: thread.id }, 'created_date', 200).catch(() => []);
      if (cancelled) return;
      setMessages(msgs);
      if (thread.unread_count > 0) {
        base44.entities.ChatThread.update(thread.id, { unread_count: 0 }).catch(() => {});
      }
    })();
    return () => { cancelled = true; };
  }, [thread?.id]);

  // Real-time subscription
  useEffect(() => {
    if (!thread?.id) return;
    const unsub = base44.entities.ChatMessage.subscribe((event) => {
      if (event.data?.thread_id === thread.id && event.type === 'create') {
        setMessages((prev) => (prev.find((m) => m.id === event.data.id) ? prev : [...prev, event.data]));
        if (event.data.sender_email !== user?.email) {
          base44.entities.ChatThread.update(thread.id, { unread_count: 0 }).catch(() => {});
        }
      }
    });
    return unsub;
  }, [thread?.id, user?.email]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = async () => {
    const content = text.trim();
    if (!content || sending || !thread?.id) return;
    setSending(true);
    setText('');

    const tempId = `temp-${Date.now()}`;
    setMessages((prev) => [...prev, {
      id: tempId, thread_id: thread.id, sender_email: user.email,
      sender_name: user.full_name, content, created_date: new Date().toISOString(),
    }]);

    const saved = await base44.entities.ChatMessage.create({
      thread_id: thread.id, sender_email: user.email,
      sender_name: user.full_name, content,
    }).catch(() => { toast.error('Грешка при изпращане'); return null; });

    if (saved) {
      setMessages((prev) => prev.map((m) => (m.id === tempId ? saved : m)));
      await base44.entities.ChatThread.update(thread.id, {
        last_message: content, last_message_at: new Date().toISOString(), unread_count: 1,
      }).catch(() => {});
      if (otherEmail) {
        base44.entities.Notification.create({
          user_email: otherEmail, type: 'system', title: 'Ново съобщение',
          message: `${user.full_name || 'Потребител'}: ${content.substring(0, 60)}`, link: '/messages',
        }).catch(() => {});
      }
    }
    setSending(false);
    inputRef.current?.focus();
  };

  const grouped = groupByDate(messages);

  return (
    <div className="flex flex-col h-full bg-muted/20">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-3 shrink-0 bg-card border-b border-border/50">
        <button onClick={onBack} className="md:hidden p-1.5 rounded-full hover:bg-muted transition-colors shrink-0">
          <ArrowLeft className="w-5 h-5 text-muted-foreground" />
        </button>
        <ChatAvatar name={otherName} size={40} />
        <div className="flex-1 min-w-0">
          <p className="font-semibold text-[15px] leading-tight truncate">{otherName}</p>
          {booking ? (
            <Link to={`/booking/${booking.id}`} className="text-xs text-primary truncate hover:underline block leading-tight">
              {booking.listing_title} · {booking.start_date} → {booking.end_date}
            </Link>
          ) : thread.listing_title ? (
            <Link to={`/listing/${thread.listing_id}`} className="text-xs text-primary truncate hover:underline block leading-tight">
              {thread.listing_title}
            </Link>
          ) : null}
        </div>
        {!isPaid && (
          <div className="flex items-center gap-1 text-[11px] text-amber-600 bg-amber-50 border border-amber-200 px-2 py-1 rounded-full shrink-0">
            <Lock className="w-3 h-3" />
            <span className="hidden sm:inline">Ограничен</span>
          </div>
        )}
      </div>

      {/* Redaction banner */}
      {!isPaid && (
        <div className="gradient-bg px-4 py-2 shrink-0 flex items-center gap-2">
          <Lock className="w-3.5 h-3.5 text-white shrink-0" />
          <p className="text-white text-[11px]">Без контактни данни — телефон, имейл и линкове се отключват след плащане</p>
        </div>
      )}

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-4" style={{ minHeight: 0 }}>
        {messages.length === 0 && (
          <div className="flex justify-center mt-10">
            <div className="bg-card text-muted-foreground text-xs px-4 py-2.5 rounded-2xl text-center max-w-[260px] shadow-sm">
              Началото на разговора. Кажи здравей! 👋
            </div>
          </div>
        )}
        {grouped.map((item) => {
          if (item.type === 'divider') {
            return (
              <div key={item.key} className="flex justify-center my-4">
                <span className="text-[11px] text-muted-foreground bg-card px-3 py-1 rounded-full shadow-sm">
                  {fmtDateDivider(item.date)}
                </span>
              </div>
            );
          }
          const { msg } = item;
          const isMe = msg.sender_email === user?.email;
          const content = redactContent(msg.content, isPaid);
          return (
            <div key={item.key} className={`flex mb-1.5 ${isMe ? 'justify-end' : 'justify-start'}`}>
              <div
                className={`relative max-w-[75%] px-3.5 pt-2 pb-5 text-sm leading-relaxed break-words whitespace-pre-wrap shadow-sm ${
                  isMe
                    ? 'gradient-bg text-white rounded-[18px] rounded-br-md'
                    : 'bg-card text-foreground rounded-[18px] rounded-bl-md border border-border/40'
                }`}
              >
                {content}
                <span className={`absolute bottom-1.5 right-3 text-[10px] whitespace-nowrap ${isMe ? 'text-white/70' : 'text-muted-foreground'}`}>
                  {fmtMsgTime(msg.created_date)}
                </span>
              </div>
            </div>
          );
        })}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div
        className="flex items-center gap-2 px-3 py-2.5 shrink-0 bg-card border-t border-border/50"
        style={{ paddingBottom: 'max(10px, env(safe-area-inset-bottom))' }}
      >
        <div className="flex-1 flex items-center bg-muted/50 rounded-full px-4 py-2.5 border border-border/40 focus-within:border-primary/30 transition-colors">
          <input
            ref={inputRef}
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); } }}
            placeholder="Напиши съобщение..."
            className="flex-1 bg-transparent text-sm placeholder:text-muted-foreground outline-none border-0 min-w-0"
            disabled={sending}
            autoComplete="off"
          />
        </div>
        <button
          onClick={sendMessage}
          disabled={!text.trim() || sending}
          className="w-10 h-10 rounded-full gradient-bg flex items-center justify-center shrink-0 hover:opacity-90 active:scale-95 transition-all disabled:opacity-30 disabled:cursor-not-allowed shadow-brand"
        >
          {sending ? <Loader2 className="w-4 h-4 text-white animate-spin" /> : <Send className="w-4 h-4 text-white" />}
        </button>
      </div>
    </div>
  );
}

export function ChatEmptyState() {
  return (
    <div className="flex flex-1 items-center justify-center bg-muted/10">
      <div className="text-center">
        <div className="w-16 h-16 gradient-bg rounded-full flex items-center justify-center mx-auto mb-4 opacity-20">
          <MessageSquare className="w-8 h-8 text-white" />
        </div>
        <p className="text-muted-foreground font-medium">Изберете разговор</p>
        <p className="text-xs text-muted-foreground/60 mt-1">За да започнете да чатите</p>
      </div>
    </div>
  );
}